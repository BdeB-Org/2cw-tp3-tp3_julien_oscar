INSERT INTO Utilisateur (ID_utilisateur, nom, addresse, telephone) VALUES
(1, 'Alice Martin', '123 Rue Principale, Paris', '0612345678'),
(2, 'Bob Dupont', '456 Avenue des Champs, Lyon', '0623456789'),
(3, 'Claire Leroy', '789 Boulevard Saint-Germain, Marseille', '0634567890');

INSERT INTO Produit (ID_produit, nom, description_produit, aliments, prix) VALUES
(1, 'Pizza Margherita', 'Pizza traditionnelle avec tomates, mozzarella, et basilic', 'tomates, mozzarella, basilic', 8.50),
(2, 'Salade C�sar', 'Salade avec laitue romaine, cro�tons, et parmesan', 'laitue, cro�tons, parmesan, sauce C�sar', 6.75),
(3, 'Spaghetti Bolognaise', 'P�tes avec sauce bolognaise', 'p�tes, viande hach�e, sauce tomate', 10.00);

INSERT INTO Menu (ID_menu, type) VALUES
(1, 'Entr�e'),
(2, 'Plat Principal'),
(3, 'Dessert');

INSERT INTO Commande (ID_commande, quantite, ID_produit) VALUES
(1, 20, 1),
(2, 10, 2),
(3, 30, 3);

INSERT INTO Reservation (ID_reservation, ID_utilisateur, nombre_places) VALUES
(1, 1, 4),
(2, 2, 2),
(3, 3, 6);

INSERT INTO Livraison (ID_livraison, ID_commande, ID_utilisateur, prix) VALUES
(1, 1, 1, 2.50),
(2, 2, 2, 3.00),
(3, 3, 3, 2.75);
