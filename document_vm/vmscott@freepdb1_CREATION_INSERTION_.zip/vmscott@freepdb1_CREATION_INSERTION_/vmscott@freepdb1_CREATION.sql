CREATE TABLE Utilisateur (
    ID_utilisateur INT PRIMARY KEY,
    nom VARCHAR(255),
    addresse VARCHAR(255),
    telephone NUMERIC
);

CREATE TABLE Produit (
    ID_produit NUMERIC PRIMARY KEY,
    nom VARCHAR(255),
    description_produit VARCHAR(255),
    aliments VARCHAR(255),
    prix NUMERIC
);

CREATE TABLE Reservation (
    ID_reservation NUMERIC PRIMARY KEY,
    ID_utilisateur NUMERIC,
    nombre_places NUMERIC,
    FOREIGN KEY (ID_utilisateur) REFERENCES Utilisateur(ID_utilisateur)
);

CREATE TABLE Commande (
    ID_commande NUMERIC PRIMARY KEY,
    quantite NUMERIC,
    ID_produit NUMERIC,
    FOREIGN KEY (ID_produit) REFERENCES Produit(ID_produit)
);

CREATE TABLE Livraison (
    ID_livraison NUMERIC PRIMARY KEY,
    ID_commande NUMERIC,
    ID_utilisateur INT,
    prix NUMERIC,
    FOREIGN KEY (ID_commande) REFERENCES Commande(ID_commande),
    FOREIGN KEY (ID_utilisateur) REFERENCES Utilisateur(ID_utilisateur)
);

CREATE TABLE Menu (
    ID_menu NUMERIC PRIMARY KEY,
    type VARCHAR(255)
);

-- URI sous le URL qui pourra etre utilise pour y activer les tables en mode REST
BEGIN
  ORDS.enable_schema(
    p_enabled             => TRUE,
    p_schema              => 'RESTSCOTT',
    p_url_mapping_type    => 'BASE_PATH',
    p_url_mapping_pattern => 'tp3',
    p_auto_rest_auth      => FALSE
  );

  COMMIT;
END;
/

--activation de la table COMMANDE pour acces REST
BEGIN
  ORDS.enable_object (
    p_enabled      => TRUE, -- Default  { TRUE | FALSE }
    p_schema       => 'RESTSCOTT',
    p_object       => 'COMMANDE',
    p_object_type  => 'TABLE', -- Default  { TABLE | VIEW }
    p_object_alias => 'commande'
  );

  COMMIT;
END;
/

--activation de la table LIVRAISON pour acces REST
BEGIN
  ORDS.enable_object (
    p_enabled      => TRUE, -- Default  { TRUE | FALSE }
    p_schema       => 'RESTSCOTT',
    p_object       => 'LIVRAISON',
    p_object_type  => 'TABLE', -- Default  { TABLE | VIEW }
    p_object_alias => 'livraison'
  );

  COMMIT;
END;
/
[14:47]
--activation de la table MENU pour acces REST
BEGIN
  ORDS.enable_object (
    p_enabled      => TRUE, -- Default  { TRUE | FALSE }
    p_schema       => 'RESTSCOTT',
    p_object       => 'MENU',
    p_object_type  => 'TABLE', -- Default  { TABLE | VIEW }
    p_object_alias => 'menu'
  );

  COMMIT;
END;
/

--activation de la table PRODUIT pour acces REST
BEGIN
  ORDS.enable_object (
    p_enabled      => TRUE, -- Default  { TRUE | FALSE }
    p_schema       => 'RESTSCOTT',
    p_object       => 'PRODUIT',
    p_object_type  => 'TABLE', -- Default  { TABLE | VIEW }
    p_object_alias => 'produit'
  );

  COMMIT;
END;
/

--activation de la table RESERVATION pour acces REST
BEGIN
  ORDS.enable_object (
    p_enabled      => TRUE, -- Default  { TRUE | FALSE }
    p_schema       => 'RESTSCOTT',
    p_object       => 'RESERVATION',
    p_object_type  => 'TABLE', -- Default  { TABLE | VIEW }
    p_object_alias => 'reservation'
  );

  COMMIT;
END;
/

--activation de la table UTILISATEUR pour acces REST
BEGIN
  ORDS.enable_object (
    p_enabled      => TRUE, -- Default  { TRUE | FALSE }
    p_schema       => 'RESTSCOTT',
    p_object       => 'UTILISATEUR',
    p_object_type  => 'TABLE', -- Default  { TABLE | VIEW }
    p_object_alias => 'utilisateur'
  );

  COMMIT;
END;
/

-- confirmation de l'Activation du schema
SELECT *
FROM user_ords_schemas;

-- confirmation de l'activation de la table emp pour REST
SELECT *
FROM   user_ords_enabled_objects;