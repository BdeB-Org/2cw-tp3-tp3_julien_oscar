CREATE TABLE Utilisateur (
    ID_utilisateur INT PRIMARY KEY,
    nom VARCHAR,
    addresse VARCHAR,
    telephone NUMERIC
);

CREATE TABLE Reservation (
    ID_reservation NUMERIC PRIMARY KEY,
    ID_utilisateur NUMERIC,
    nombre_places NUMERIC,
    FOREIGN KEY (ID_utilisateur) REFERENCES Utilisateur(ID_utilisateur)
);

CREATE TABLE Commande (
    ID_commande NUMERIC PRIMARY KEY,
    quantite NUMERIC,
    ID_produit NUMERIC,
    FOREIGN KEY (ID_produit) REFERENCES Utilisateur(ID_produit)
);

CREATE TABLE Livraison (
    ID_livraison NUMERIC PRIMARY KEY,
    ID_commande NUMERIC,
    prix NUMERIC,
    FOREIGN KEY (ID_commande) REFERENCES Commande(ID_commande),
    FOREIGN KEY (ID_utilisateur) REFERENCES Utilisateur(ID_utilisateur)
);

CREATE TABLE Produit (
    ID_produit NUMERIC PRIMARY KEY,
    nom VARCHAR,
    description_produit VARCHAR,
    aliments VARCHAR,
    prix NUMERIC
);

CREATE TABLE Menu (
    ID_menu NUMERIC PRIMARY KEY,
    type VARCHAR
);
